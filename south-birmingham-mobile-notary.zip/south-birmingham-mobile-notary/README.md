# South Birmingham Mobile Notary (Website)

A classy, single-page mobile-notary website built with **Next.js + Tailwind**.

## Quick start

1) Install dependencies:

```bash
npm install
```

2) Run locally:

```bash
npm run dev
```

Then open: http://localhost:3000

## Deploy to Vercel (recommended)

1) Push this folder to a GitHub repo
2) Go to https://vercel.com/new and import the repo
3) Click **Deploy**
4) In Vercel: **Settings → Domains** and add your GoDaddy domain
5) Update GoDaddy DNS to the records Vercel shows

## Notes
- The contact form intentionally **copies** a ready-to-send message (it does not send automatically).
- Phone is click-to-call: **(404) 512-2524**.
