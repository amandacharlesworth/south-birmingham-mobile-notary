import "./globals.css";

export const metadata = {
  title: "South Birmingham Mobile Notary",
  description: "Mobile notary service in Hoover, McCalla, Homewood, and Vestavia Hills.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
