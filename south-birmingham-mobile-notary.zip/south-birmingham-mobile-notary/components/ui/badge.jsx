import React from "react";
import { cn } from "@/lib/utils";

const variants = {
  default: "bg-slate-950 text-white",
  secondary: "bg-slate-100 text-slate-800 border border-slate-200",
};

export function Badge({ className, variant = "default", ...props }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-xl px-3 py-1 text-xs font-medium",
        variants[variant] || variants.default,
        className
      )}
      {...props}
    />
  );
}
